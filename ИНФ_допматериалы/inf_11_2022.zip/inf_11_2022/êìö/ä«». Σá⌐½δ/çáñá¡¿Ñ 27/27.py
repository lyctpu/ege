with open('27_A.txt')as f:
    sp=[int (x) for x in f]
sp_c=[]
sp_summ=[]
c=0
summ=0
sp_ra=[]
status=True
print(len(sp))
for i in range (len(sp)):
    if sp[i] %43==0:
        c+=1
        summ+=sp[i]
        if status==True:
            sp_ra.append(f'{i}-откр')
            status=False
    else:
        sp_c.append(c)
        sp_summ.append(summ)
        c=0
        summ=0
        if status==False:
            sp_ra.append(f'{i}-закр')
            status=True
print(sp_c)
print(sp_summ)
print(sp_ra)
if (sp[31]+sp[401])%43==0:print(f'1 пара есть {sp[31]+sp[401]}')
if (sp[401]+sp[587])%43==0:print(f'1 пара есть {sp[401]+sp[587]}')
